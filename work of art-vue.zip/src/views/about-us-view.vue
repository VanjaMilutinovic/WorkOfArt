<template>
  <div class="about-us-view-container">
    <app-header rootClassName="header-root-class-name"></app-header>
    <h1 class="about-us-view-text">Ovo smo mi!</h1>
    <span class="about-us-view-text1">Neki tekst o nama. Lorem ipsum</span>
    <app-gallery rootClassName="gallery-root-class-name"></app-gallery>
    <div class="about-us-view-banner">
      <h2 class="about-us-view-text2">
        <span>Ovo je umesto mape</span>
        <br class="about-us-view-text4" />
        <span><span v-html="rawmxb2"></span></span>
      </h2>
    </div>
    <h1 class="about-us-view-text6">
      <span>
        Kontaktirajte nas!
        <span v-html="raws67u"></span>
      </span>
      <span class="about-us-view-text8">064 987 345</span>
    </h1>
    <app-footer rootClassName="footer-root-class-name"></app-footer>
  </div>
</template>

<script>
import AppHeader from '../components/header'
import AppGallery from '../components/gallery'
import AppFooter from '../components/footer'

export default {
  name: 'AboutUsView',
  components: {
    AppHeader,
    AppGallery,
    AppFooter,
  },
  data() {
    return {
      rawmxb2: ' ',
      raws67u: ' ',
    }
  },
  metaInfo: {
    title: 'AboutUsView - Work Of Art',
    meta: [
      {
        property: 'og:title',
        content: 'AboutUsView - Work Of Art',
      },
    ],
  },
}
</script>

<style scoped>
.about-us-view-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.about-us-view-text {
  color: #303030;
  margin: var(--dl-space-space-twounits);
}
.about-us-view-text1 {
  margin-left: var(--dl-space-space-threeunits);
  margin-right: var(--dl-space-space-threeunits);
}
.about-us-view-banner {
  width: 100%;
  display: flex;
  padding: var(--dl-space-space-threeunits);
  align-items: center;
  margin-left: var(--dl-space-space-threeunits);
  margin-right: var(--dl-space-space-threeunits);
  margin-bottom: var(--dl-space-space-threeunits);
  flex-direction: column;
  justify-content: space-between;
  background-color: var(--dl-color-gray-700);
}
.about-us-view-text2 {
  margin: 0px;
  text-align: center;
  font-weight: 600;
}
.about-us-view-text4 {
  font-weight: 600;
}
.about-us-view-text6 {
  color: rgb(48, 48, 48);
  margin: var(--dl-space-space-twounits);
}
.about-us-view-text8 {
  text-decoration: underline;
}
@media(max-width: 991px) {
  .about-us-view-text2 {
    text-align: center;
  }
}
@media(max-width: 767px) {
  .about-us-view-banner {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
}
@media(max-width: 479px) {
  .about-us-view-banner {
    padding-top: var(--dl-space-space-twounits);
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: var(--dl-space-space-twounits);
  }
}
</style>

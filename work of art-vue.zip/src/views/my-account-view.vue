<template>
  <div class="my-account-view-container">
    <app-header rootClassName="header-root-class-name6"></app-header>
    <button type="button" class="my-account-view-button button">
      Izloguj se
    </button>
    <h1>Zdravo, Milice!</h1>
    <span class="my-account-view-text1">Ne bi bilo lose neki tekstic ovde</span>
    <all-my-offers-component
      rootClassName="all-my-offers-component-root-class-name"
    ></all-my-offers-component>
    <app-footer rootClassName="footer-root-class-name6"></app-footer>
  </div>
</template>

<script>
import AppHeader from '../components/header'
import AllMyOffersComponent from '../components/all-my-offers-component'
import AppFooter from '../components/footer'

export default {
  name: 'MyAccountView',
  components: {
    AppHeader,
    AllMyOffersComponent,
    AppFooter,
  },
  metaInfo: {
    title: 'MyAccountView - Work Of Art',
    meta: [
      {
        property: 'og:title',
        content: 'MyAccountView - Work Of Art',
      },
    ],
  },
}
</script>

<style scoped>
.my-account-view-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.my-account-view-button {
  color: rgb(255, 255, 255);
  font-size: 20px;
  align-self: flex-start;
  font-style: normal;
  margin-top: var(--dl-space-space-threeunits);
  font-weight: 600;
  margin-left: var(--dl-space-space-threeunits);
  padding-top: var(--dl-space-space-halfunit);
  padding-left: var(--dl-space-space-unit);
  padding-right: var(--dl-space-space-unit);
  padding-bottom: var(--dl-space-space-halfunit);
  background-color: rgb(48, 48, 48);
}
.my-account-view-text1 {
  margin-top: var(--dl-space-space-unit);
  margin-left: var(--dl-space-space-sixunits);
  margin-right: var(--dl-space-space-sixunits);
  margin-bottom: var(--dl-space-space-unit);
}
</style>

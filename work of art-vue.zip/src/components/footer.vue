<template>
  <footer class="footer-footer" v-bind:class="rootClassName">
    <img :alt="image_alt" :src="image_src" class="footer-image" />
    <span class="footer-text">{{ text }}</span>
  </footer>
</template>

<script>
export default {
  name: 'Footer',
  props: {
    image_alt: {
      type: String,
      default: 'logo',
    },
    image_src: {
      type: String,
      default: '/new%20project-1500h.png',
    },
    text: {
      type: String,
      default: 'Ovde ide zadati predifined tekst',
    },
    rootClassName: String,
  },
}
</script>

<style scoped>
.footer-footer {
  width: 100%;
  display: flex;
  position: relative;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  padding-top: var(--dl-space-space-twounits);
  padding-left: var(--dl-space-space-threeunits);
  padding-right: var(--dl-space-space-threeunits);
  padding-bottom: var(--dl-space-space-twounits);
  justify-content: space-between;
  background-color: #edc0f1;
}
.footer-image {
  height: 2rem;
  object-fit: cover;
}
.footer-text {
  color: #303030;
}
.footer-root-class-name {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name1 {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name2 {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name3 {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name4 {
  left: 0px;
  bottom: 0px;
  position: static;
  align-self: center;
}
.footer-root-class-name5 {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name6 {
  left: 0px;
  bottom: 0px;
  position: static;
}
.footer-root-class-name7 {
  left: 0px;
  bottom: 0px;
  position: static;
}
@media(max-width: 767px) {
  .footer-footer {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .footer-text {
    text-align: center;
    margin-left: var(--dl-space-space-unit);
    margin-right: var(--dl-space-space-unit);
  }
}
@media(max-width: 479px) {
  .footer-footer {
    padding: var(--dl-space-space-unit);
    flex-direction: column;
  }
  .footer-image {
    margin-bottom: var(--dl-space-space-unit);
  }
  .footer-text {
    margin-left: 0px;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-unit);
  }
}
</style>

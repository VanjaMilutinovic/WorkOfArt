<template>
  <div class="all-my-offers-component-art-offers" v-bind:class="rootClassName">
    <h1 class="all-my-offers-component-text">{{ heading }}</h1>
    <div class="all-my-offers-component-container">
      <my-art-offer-component
        rootClassName="my-art-offer-component-root-class-name"
      ></my-art-offer-component>
    </div>
    <div class="all-my-offers-component-container1">
      <my-art-offer-component
        rootClassName="my-art-offer-component-root-class-name1"
      ></my-art-offer-component>
    </div>
  </div>
</template>

<script>
import MyArtOfferComponent from './my-art-offer-component'

export default {
  name: 'AllMyOffersComponent',
  props: {
    rootClassName: String,
    heading: {
      type: String,
      default: 'Sve ponude',
    },
  },
  components: {
    MyArtOfferComponent,
  },
}
</script>

<style scoped>
.all-my-offers-component-art-offers {
  width: 100%;
  display: flex;
  position: relative;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  padding-left: var(--dl-space-space-threeunits);
  padding-right: var(--dl-space-space-threeunits);
  flex-direction: column;
  justify-content: space-between;
}
.all-my-offers-component-text {
  color: rgb(48, 48, 48);
  padding: var(--dl-space-space-unit);
  padding-left: 16px;
}
.all-my-offers-component-container {
  width: 100%;
  display: flex;
  max-width: 100%;
  align-items: center;
  margin-bottom: var(--dl-space-space-twounits);
  flex-direction: column;
  justify-content: space-between;
}
.all-my-offers-component-container1 {
  width: 100%;
  display: flex;
  max-width: 100%;
  align-items: center;
  margin-bottom: var(--dl-space-space-twounits);
  flex-direction: column;
  justify-content: space-between;
}

@media(max-width: 767px) {
  .all-my-offers-component-art-offers {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
}
@media(max-width: 479px) {
  .all-my-offers-component-art-offers {
    padding-top: var(--dl-space-space-twounits);
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: var(--dl-space-space-twounits);
  }
}
</style>

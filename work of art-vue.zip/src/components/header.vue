<template>
  <header
    data-role="Accordion"
    class="header-header"
    v-bind:class="rootClassName"
  >
    <img :alt="image_alt" :src="image_src" class="header-image" />
    <div class="header-separator"></div>
    <div class="header-container">
      <div data-role="AccordionHeader" class="header-accordion-header">
        <svg viewBox="0 0 1024 1024" class="header-icon">
          <path
            d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
          ></path>
        </svg>
      </div>
      <div data-role="AccordionContent" class="header-accordion-content">
        <div class="header-nav">
          <navigation-links-component
            rootClassName="rootClassName20"
          ></navigation-links-component>
        </div>
      </div>
      <div class="header-container1">
        <nav class="header-nav1">
          <navigation-links-component
            rootClassName="rootClassName19"
          ></navigation-links-component>
        </nav>
        <button type="button" class="header-button button">{{ button }}</button>
      </div>
    </div>
  </header>
</template>

<script>
import NavigationLinksComponent from './navigation-links-component'

export default {
  name: 'Header',
  props: {
    rootClassName: String,
    button: {
      type: String,
      default: 'ENG',
    },
    image_alt: {
      type: String,
      default: 'logo',
    },
    image_src: {
      type: String,
      default: '/new%20project-1500h.png',
    },
  },
  components: {
    NavigationLinksComponent,
  },
}
</script>

<style scoped>
.header-header {
  width: 100%;
  display: flex;
  position: relative;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  padding-top: var(--dl-space-space-twounits);
  padding-left: var(--dl-space-space-threeunits);
  padding-right: var(--dl-space-space-threeunits);
  flex-direction: column;
  padding-bottom: var(--dl-space-space-twounits);
  background-color: #edc0f1;
}
.header-image {
  height: 2rem;
}
.header-separator {
  width: 100%;
  height: 1px;
  margin-top: var(--dl-space-space-oneandhalfunits);
  margin-bottom: var(--dl-space-space-oneandhalfunits);
  background-color: #303030;
}
.header-container {
  flex: 0 0 auto;
  width: 100%;
  height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.header-accordion-header {
  display: none;
  align-items: center;
  flex-direction: column;
}
.header-icon {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
  display: none;
}
.header-accordion-content {
  display: none;
  overflow: hidden;
  max-height: 0;
  transition: 0.3s ease-in-out;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.header-nav {
  display: flex;
  align-items: center;
  flex-direction: column;
}
.header-container1 {
  flex: 0 0 auto;
  width: auto;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.header-nav1 {
  flex: auto;
}
.header-button {
  color: var(--dl-color-gray-white);
  width: 80px;
  height: 36px;
  align-self: flex-end;
  font-style: normal;
  margin-top: 0px;
  font-weight: 600;
  margin-left: var(--dl-space-space-oneandhalfunits);
  padding-top: 4px;
  border-color: var(--dl-color-gray-white);
  margin-right: var(--dl-space-space-oneandhalfunits);
  padding-left: 8px;
  padding-right: 8px;
  padding-bottom: 4px;
  background-color: #303030;
}
.header-root-class-name {
  top: 0px;
  left: 0px;
  position: static;
}
.header-root-class-name1 {
  top: 0px;
  left: 0px;
  position: static;
}
.header-root-class-name2 {
  top: 0px;
  left: 0px;
  position: static;
}
.header-root-class-name3 {
  top: 0px;
  left: 0px;
  position: static;
}
.header-root-class-name4 {
  position: 0px;
}

.header-root-class-name6 {
  top: 0px;
  left: 0px;
  position: static;
}

@media(max-width: 991px) {
  .header-container {
    justify-content: center;
  }
  .header-nav {
    padding-top: 16px;
  }
}
@media(max-width: 767px) {
  .header-header {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .header-separator {
    margin-top: var(--dl-space-space-oneandhalfunits);
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .header-accordion-header {
    display: flex;
    align-items: flex-start;
  }
  .header-icon {
    width: 15%;
    height: 15%;
    display: flex;
  }
  .header-accordion-content {
    display: flex;
  }
  .header-nav1 {
    display: none;
  }
}
@media(max-width: 479px) {
  .header-header {
    padding: var(--dl-space-space-unit);
  }
  .header-separator {
    margin-top: var(--dl-space-space-unit);
    margin-bottom: var(--dl-space-space-unit);
  }
  .header-container {
    height: 100%;
    align-self: center;
    align-items: stretch;
    justify-content: space-between;
  }
  .header-accordion-header {
    height: 100%;
    margin-top: 0px;
    margin-left: var(--dl-space-space-twounits);
    margin-right: var(--dl-space-space-twounits);
    margin-bottom: 0px;
  }
}
</style>

<template>
  <div class="artist-card-component-testimonial">
    <img :alt="image_alt" :src="image_src" class="artist-card-component-image" />
    <div class="artist-card-component-testimonial1">
      <div class="artist-card-component-container">
        <svg
          viewBox="0 0 950.8571428571428 1024"
          class="artist-card-component-icon"
        >
          <path
            d="M438.857 548.571v219.429c0 60.571-49.143 109.714-109.714 109.714h-219.429c-60.571 0-109.714-49.143-109.714-109.714v-402.286c0-161.143 131.429-292.571 292.571-292.571h36.571c20 0 36.571 16.571 36.571 36.571v73.143c0 20-16.571 36.571-36.571 36.571h-36.571c-80.571 0-146.286 65.714-146.286 146.286v18.286c0 30.286 24.571 54.857 54.857 54.857h128c60.571 0 109.714 49.143 109.714 109.714zM950.857 548.571v219.429c0 60.571-49.143 109.714-109.714 109.714h-219.429c-60.571 0-109.714-49.143-109.714-109.714v-402.286c0-161.143 131.429-292.571 292.571-292.571h36.571c20 0 36.571 16.571 36.571 36.571v73.143c0 20-16.571 36.571-36.571 36.571h-36.571c-80.571 0-146.286 65.714-146.286 146.286v18.286c0 30.286 24.571 54.857 54.857 54.857h128c60.571 0 109.714 49.143 109.714 109.714z"
          ></path>
        </svg>
      </div>
      <span class="artist-card-component-text">
        <span>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lorem lorem,
          malesuada in metus vitae, scelerisque accumsan ipsum. Nam pellentesque
          nulla leo, sagittis vehicula sem commodo nec.
        </span>
        <br />
        <span></span>
      </span>
      <div class="artist-card-component-container1">
        <svg
          viewBox="0 0 950.8571428571428 1024"
          class="artist-card-component-icon2"
        >
          <path
            d="M438.857 182.857v402.286c0 161.143-131.429 292.571-292.571 292.571h-36.571c-20 0-36.571-16.571-36.571-36.571v-73.143c0-20 16.571-36.571 36.571-36.571h36.571c80.571 0 146.286-65.714 146.286-146.286v-18.286c0-30.286-24.571-54.857-54.857-54.857h-128c-60.571 0-109.714-49.143-109.714-109.714v-219.429c0-60.571 49.143-109.714 109.714-109.714h219.429c60.571 0 109.714 49.143 109.714 109.714zM950.857 182.857v402.286c0 161.143-131.429 292.571-292.571 292.571h-36.571c-20 0-36.571-16.571-36.571-36.571v-73.143c0-20 16.571-36.571 36.571-36.571h36.571c80.571 0 146.286-65.714 146.286-146.286v-18.286c0-30.286-24.571-54.857-54.857-54.857h-128c-60.571 0-109.714-49.143-109.714-109.714v-219.429c0-60.571 49.143-109.714 109.714-109.714h219.429c60.571 0 109.714 49.143 109.714 109.714z"
          ></path>
        </svg>
      </div>
    </div>
    <span class="artist-card-component-text3">Van Gogh</span>
    <span class="artist-card-component-text4">Preuzmi spisak dela</span>
  </div>
</template>

<script>
export default {
  name: 'ArtistCardComponent',
  props: {
    image_alt: {
      type: String,
      default: 'image',
    },
    image_src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fHBvcnRyYWl0fGVufDB8fHx8MTYyNjM3ODk3Mg&ixlib=rb-1.2.1&h=1000',
    },
  },
}
</script>

<style scoped>
.artist-card-component-testimonial {
  width: 100%;
  display: flex;
  padding: var(--dl-space-space-threeunits);
  position: relative;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
}
.artist-card-component-image {
  width: var(--dl-size-size-xxlarge);
  height: var(--dl-size-size-xxlarge);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.artist-card-component-testimonial1 {
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.artist-card-component-container {
  display: flex;
  align-self: flex-start;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.artist-card-component-icon {
  width: var(--dl-size-size-small);
  margin-bottom: -6rem;
}
.artist-card-component-text {
  font-size: 1.15rem;
  max-width: 600px;
  margin-top: var(--dl-space-space-threeunits);
  text-align: center;
  padding-left: var(--dl-space-space-twounits);
  margin-bottom: var(--dl-space-space-threeunits);
  padding-right: var(--dl-space-space-twounits);
}
.artist-card-component-container1 {
  display: flex;
  align-self: flex-end;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.artist-card-component-icon2 {
  width: var(--dl-size-size-small);
  margin-top: -6rem;
}
.artist-card-component-text3 {
  font-size: 1.5rem;
  max-width: 600px;
  text-align: center;
  font-weight: 600;
  margin-bottom: var(--dl-space-space-halfunit);
}
.artist-card-component-text4 {
  color: var(--dl-color-gray-500);
  max-width: 600px;
  font-style: normal;
  text-align: center;
  font-weight: 500;
  text-decoration: underline;
}
@media(max-width: 991px) {
  .artist-card-component-image {
    margin-bottom: 0px;
  }
  .artist-card-component-text {
    margin-top: var(--dl-space-space-threeunits);
    margin-bottom: var(--dl-space-space-threeunits);
  }
}
@media(max-width: 767px) {
  .artist-card-component-testimonial {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
}
@media(max-width: 479px) {
  .artist-card-component-testimonial {
    padding-top: var(--dl-space-space-twounits);
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: var(--dl-space-space-twounits);
  }
  .artist-card-component-image {
    width: 200px;
  }
  .artist-card-component-icon {
    margin-bottom: 0px;
  }
  .artist-card-component-text {
    width: auto;
  }
  .artist-card-component-icon2 {
    margin-bottom: var(--dl-space-space-unit);
  }
}
</style>

<template>
  <div class="single-art-component-single-art-component">
    <img :alt="image_alt" :src="image_src" class="single-art-component-image" />
    <div class="single-art-component-container">
      <h1 class="single-art-component-text">{{ name }}</h1>
      <h3 class="single-art-component-text01">{{ author }}</h3>
      <span class="single-art-component-text02">
        <br />
        <span>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non
          volutpat turpis.
          <span v-html="raw6req"></span>
        </span>
        <span><span v-html="raw8wtg"></span></span>
        <span>
          Mauris luctus rutrum mi ut rhoncus. Integer in dignissim tortor.
          <span v-html="rawua0a"></span>
        </span>
        <span><span v-html="rawnjtx"></span></span>
      </span>
      <button class="single-art-component-button button">{{ viewAll }}</button>
    </div>
    <div class="single-art-component-container1">
      <span class="single-art-component-text08">
        <span>Unesite s</span>
        <span>voju ponudu</span>
        <br />
        <span><span v-html="rawu8iw"></span></span>
        <span><span v-html="rawdd9x"></span></span>
      </span>
      <textarea
        :placeholder="offer"
        class="single-art-component-textarea textarea"
      ></textarea>
      <button class="single-art-component-button1 button">
        {{ offerButton }}
      </button>
    </div>
    <div class="single-art-component-container2">
      <span class="single-art-component-text14">
        <span>Unesite svoju poruku</span>
        <br />
        <span><span v-html="rawm3nu"></span></span>
        <span><span v-html="rawboao"></span></span>
      </span>
      <textarea
        :placeholder="msg"
        class="single-art-component-textarea1 textarea"
      ></textarea>
      <button class="single-art-component-button2 button">
        {{ sendButton }}
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SingleArtComponent',
  props: {
    image_alt: {
      type: String,
      default: 'image',
    },
    viewAll: {
      type: String,
      default: 'pogledaj sve ponude',
    },
    offerButton: {
      type: String,
      default: 'ponudi',
    },
    sendButton: {
      type: String,
      default: 'posalji',
    },
    msg: {
      type: String,
      default: 'ex. my message',
    },
    image_src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1471086569966-db3eebc25a59?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDIwfHxtaW5pbWFsaXNtJTIwcGxhbnR8ZW58MHx8fHwxNjI2MTgyODMw&ixlib=rb-1.2.1&w=1200',
    },
    offer: {
      type: String,
      default: 'ex. 500$',
    },
    name: {
      type: String,
      default: 'Zvezdana noc',
    },
    author: {
      type: String,
      default: 'Van Gogh',
    },
  },
  data() {
    return {
      raw6req: ' ',
      raw8wtg: ' ',
      rawua0a: ' ',
      rawnjtx: ' ',
      rawu8iw: ' ',
      rawdd9x: ' ',
      rawm3nu: ' ',
      rawboao: ' ',
    }
  },
}
</script>

<style scoped>
.single-art-component-single-art-component {
  width: 100%;
  display: flex;
  padding: var(--dl-space-space-threeunits);
  position: relative;
  min-height: 80vh;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.single-art-component-image {
  width: 45rem;
  margin-top: var(--dl-space-space-twounits);
}
.single-art-component-container {
  display: flex;
  align-items: center;
  flex-direction: column;
}
.single-art-component-text {
  font-size: 3rem;
}
.single-art-component-text01 {
  color: #303030;
  font-size: 2rem;
  font-style: normal;
  font-weight: 500;
}
.single-art-component-text02 {
  margin-top: var(--dl-space-space-twounits);
  text-align: center;
  padding-left: var(--dl-space-space-threeunits);
  margin-bottom: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-threeunits);
}
.single-art-component-button {
  transition: 0.3s;
  padding-top: var(--dl-space-space-unit);
  padding-left: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-twounits);
  padding-bottom: var(--dl-space-space-unit);
}
.single-art-component-button:hover {
  transform: scale(1.02);
}
.single-art-component-container1 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.single-art-component-text08 {
  margin-top: var(--dl-space-space-twounits);
  text-align: center;
  padding-left: var(--dl-space-space-threeunits);
  margin-bottom: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-threeunits);
}
.single-art-component-textarea {
  width: 100%;
  margin: var(--dl-space-space-oneandhalfunits);
  padding: var(--dl-space-space-halfunit);
  max-width: 100%;
  min-width: auto;
}
.single-art-component-button1 {
  margin: var(--dl-space-space-oneandhalfunits);
  transition: 0.3s;
  padding-top: var(--dl-space-space-unit);
  padding-left: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-twounits);
  padding-bottom: var(--dl-space-space-unit);
}
.single-art-component-button1:hover {
  transform: scale(1.02);
}
.single-art-component-container2 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.single-art-component-text14 {
  margin-top: var(--dl-space-space-twounits);
  text-align: center;
  padding-left: var(--dl-space-space-threeunits);
  margin-bottom: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-threeunits);
}
.single-art-component-textarea1 {
  width: 100%;
  margin: var(--dl-space-space-oneandhalfunits);
  padding: var(--dl-space-space-halfunit);
  max-width: 100%;
  min-width: auto;
}
.single-art-component-button2 {
  margin: var(--dl-space-space-oneandhalfunits);
  transition: 0.3s;
  padding-top: var(--dl-space-space-unit);
  padding-left: var(--dl-space-space-twounits);
  padding-right: var(--dl-space-space-twounits);
  padding-bottom: var(--dl-space-space-unit);
}
.single-art-component-button2:hover {
  transform: scale(1.02);
}
@media(max-width: 991px) {
  .single-art-component-single-art-component {
    flex-direction: column;
  }
  .single-art-component-image {
    width: 80%;
  }
  .single-art-component-container {
    align-items: center;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-twounits);
  }
  .single-art-component-text {
    text-align: center;
  }
  .single-art-component-text01 {
    text-align: center;
  }
  .single-art-component-text02 {
    text-align: center;
  }
  .single-art-component-container1 {
    align-items: center;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-twounits);
  }
  .single-art-component-text08 {
    text-align: center;
  }
  .single-art-component-container2 {
    align-items: center;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-twounits);
  }
  .single-art-component-text14 {
    text-align: center;
  }
}
@media(max-width: 767px) {
  .single-art-component-single-art-component {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .single-art-component-text02 {
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
  }
  .single-art-component-text08 {
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
  }
  .single-art-component-text14 {
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
  }
}
@media(max-width: 479px) {
  .single-art-component-single-art-component {
    padding-top: var(--dl-space-space-twounits);
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: var(--dl-space-space-twounits);
  }
  .single-art-component-container {
    margin-bottom: var(--dl-space-space-unit);
  }
  .single-art-component-button {
    margin-top: var(--dl-space-space-unit);
    margin-left: 0px;
  }
  .single-art-component-container1 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .single-art-component-button1 {
    margin-top: var(--dl-space-space-unit);
    margin-left: 0px;
  }
  .single-art-component-container2 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .single-art-component-button2 {
    margin-top: var(--dl-space-space-unit);
    margin-left: 0px;
  }
}
</style>

<template>
  <div class="art-type-component-testimonial-card" v-bind:class="rootClassName">
    <div class="art-type-component-testimonial">
      <span class="art-type-component-text">{{ type }}</span>
      <img
        :alt="picture_alt"
        :src="picture_src"
        class="art-type-component-image"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'ArtTypeComponent',
  props: {
    type: {
      type: String,
      default: 'SLIKE',
    },
    rootClassName: String,
    picture_alt: {
      type: String,
      default: 'profile',
    },
    picture_src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDd8fHBvcnRyYWl0fGVufDB8fHx8MTYyNjM3ODk3Mg&ixlib=rb-1.2.1&w=300',
    },
    quote: {
      type: String,
      default:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In lorem lorem, malesuada in metus vitae, scelerisque accumsan ipsum.  Nam pellentesque nulla leo, sagittis vehicula sem commodo nec.',
    },
    name: {
      type: String,
      default: 'Jane Doe',
    },
  },
}
</script>

<style scoped>
.art-type-component-testimonial-card {
  display: flex;
  padding: var(--dl-space-space-unit);
  max-width: var(--dl-size-size-maxwidth);
  background: #fff;
  box-shadow: 15px 15px 20px 0px rgba(18, 18, 18, 0.1);
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
}
.art-type-component-testimonial {
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
}
.art-type-component-text {
  color: var(--dl-color-gray-500);
  font-weight: 600;
  margin-bottom: var(--dl-space-space-unit);
  text-transform: uppercase;
}
.art-type-component-image {
  width: var(--dl-size-size-xxlarge);
  height: var(--dl-size-size-xxlarge);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}



@media(max-width: 991px) {
  .art-type-component-text {
    align-self: center;
  }
}
@media(max-width: 767px) {
  .art-type-component-testimonial-card {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
}
@media(max-width: 479px) {
  .art-type-component-testimonial-card {
    padding-top: var(--dl-space-space-twounits);
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: var(--dl-space-space-twounits);
  }
  .art-type-component-text {
    margin-bottom: var(--dl-space-space-unit);
  }
}
</style>
